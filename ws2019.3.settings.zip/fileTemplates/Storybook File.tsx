import React from 'react';
import styled from 'styled-components';
import { addDecorator, storiesOf } from '@storybook/react';
import StoryRouter from 'storybook-react-router';
import { withA11y } from '@storybook/addon-a11y';

addDecorator(withA11y);
const stories = storiesOf(#[[$Title$]]#, module);

stories.addDecorator(StoryRouter());
