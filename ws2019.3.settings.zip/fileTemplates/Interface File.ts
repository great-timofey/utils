import React from 'react';

export interface #[[$Title$]]# {
  
}